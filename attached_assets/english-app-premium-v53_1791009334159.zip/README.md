English App Premium v52

Ready for Netlify / static hosting.
Files:
- index.html
- english-intro.mp4

Upload the three files from the ZIP to the site root. No build step and no API key are required.
